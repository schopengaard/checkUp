@extends('layouts.app')
@section('title', 'Schedule Page')

@section('topPart')
<div class="container mt-4">
	<div class="row justify-content-center">
		<!-- Profile Header -->
		@include('partials._doctorHeader')
		@include('partials._doctortabs', array([$tab[0]=''], [$tab[1]=''], [$tab[2]=''], [$tab[3]='active']))
	</div>
</div>
@endsection

@section('content')
<div class="row col-sm-12 px-0 mx-0 mb-3">
	<div class="flex-grow-1">
		<form action="{{ action('DoctorController@search_schedule') }}" method="get">
			<div class="input-group">
				<input type="text" name="search_schedule" class="form-control" placeholder="Search Schedule" aria-label="Search Schedule" aria-describedby="basic-addon2">
				<div class="input-group-append">
					<button type="submit" class="btn btn-outline-secondary">Search</button>
				</div>
			</div>
		</form>
	</div>
</div>
<div class="card mb-3" style="border-radius: 15px; border-color: #A3BBB5">
	<form class="" action="index.html" method="post">

	</form>
<table class="table table-sm table-hover tableBack mb-0" >
	<thead>
		<tr>
			<th class="text-right">Day</th>
			<th class="text-center">Date</th>
			<th class="text-center">Week</th>
			<th class="text-center">09:00 AM</th>
			<th class="text-center">10:00 AM</th>
			<th class="text-center">11:00 AM</th>
			<th class="text-center">12:00 PM</th>
			<th class="text-center">01:00 PM</th>
			<th class="text-center">02:00 PM</th>
			<th class="text-center">03:00 PM</th>
			<th class="text-center">04:00 PM</th>
			<th width="30px"></th>
		</tr>
	</thead>
	<tbody>
		@foreach($schedule as $row)
		<tr>
			<td class="text-right">{{ $row->day_of_week }}</td>
			<td>{{ $row->date }}</td>
			<td>
				@if($row->day == null)
				<div class="text-center">
					<input id="t0" type="checkbox" data-toggle="toggle" data-on="AVAILABLE" data-off="OFF" data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@else
				<div class="text-center">
					<input id="t0" type="checkbox" checked data-toggle="toggle" data-on="AVAILABLE" data-off="OFF" data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@endif
			</td>
			<td>
				@if($row->h1 == null)
				<div class="text-center">
					<input id="t1" type="checkbox" checked data-toggle="toggle" data-on=" " data-off=" " data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@else
				<div class="text-center">
					{{$row->h1}}
				</div>
				@endif
			</td>
			<td>
				@if($row->h2 == null)
				<div class="text-center">
					<input type="checkbox" checked data-toggle="toggle" data-on=" " data-off=" " data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@else
				<div class="text-center">
					{{$row->h2}}
				</div>
				@endif
			</td>
			<td>
				@if($row->h3 == null)
				<div class="text-center">
					<input type="checkbox" checked data-toggle="toggle" data-on=" " data-off=" " data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@else
				<div class="text-center">
					{{$row->h3}}
				</div>
				@endif
			</td>
			<td>
				@if($row->h4 == null)
				<div class="text-center">
					<input type="checkbox" checked data-toggle="toggle" data-on=" " data-off=" " data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@else
				<div class="text-center">
					{{$row->h4}}
				</div>
				@endif
			</td>
			<td>
				@if($row->h5 == null)
				<div class="text-center">
					<input type="checkbox" checked data-toggle="toggle" data-on=" " data-off=" " data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@else
				<div class="text-center">
					{{$row->h5}}
				</div>
				@endif
			</td>
			<td>
				@if($row->h6 == null)
				<div class="text-center">
					<input type="checkbox" checked data-toggle="toggle" data-on=" " data-off=" " data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@else
				<div class="text-center">
					{{$row->h6}}
				</div>
				@endif
			</td>
			<td>
				@if($row->h7 == null)
				<div class="text-center">
					<input type="checkbox" checked data-toggle="toggle" data-on=" " data-off=" " data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@else
				<div class="text-center">
					{{$row->h7}}
				</div>
				@endif
			</td>
			<td>
				@if($row->h8 == null)
				<div class="text-center">
					<input type="checkbox" checked data-toggle="toggle" data-on=" " data-off=" " data-onstyle="primary" data-offstyle="secondary" data-size="small">
				</div>
				@else
				<div class="text-center">
					{{$row->h8}}
				</div>
				@endif
			</td>
			<td class="text-right">
				@include('partials._dropdown', array([$drop[0]='DoctorController@show_schedule'], [$drop[1]='DoctorController@edit_schedule'], [$drop[2]='DoctorController@destroy_schedule']))
			</td>
		</tr>
		@endforeach
	</tbody>
</table>
</div>
@endsection
@section('scripts')
<script>
$(document).ready(function() {
	$("#t0").click(
		function(){$("#t1").prop('checked', false).change();
	});
});
</script>
@endsection
